document.addEventListener('DOMContentLoaded', () => {
  const navToggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.site-nav');
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  if (navToggle) {
    navToggle.addEventListener('click', () => {
      const open = nav.style.display === 'block';
      nav.style.display = open ? 'none' : 'block';
      navToggle.setAttribute('aria-expanded', String(!open));
    });
  }

  const reservationForm = document.getElementById('reservationForm');
  if (reservationForm) {
    reservationForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(reservationForm).entries());
      alert(`Thanks ${data.name}! Reservation requested for ${data.guests} on ${data.date} at ${data.time}. We will confirm by phone.`);
      reservationForm.reset();
    });
  }

  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(contactForm).entries());
      alert(`Thank you, ${data.name}! We will get back to you at ${data.phone}.`);
      contactForm.reset();
    });
  }
});

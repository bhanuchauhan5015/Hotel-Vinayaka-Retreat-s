# Restaurant Website Template

A clean, responsive, multi-page template for a restaurant.

## Pages
- `index.html` (Home)
- `menu.html`
- `about.html`
- `gallery.html`
- `contact.html`
- `reservations.html`

## Customize
- Find & replace **Your Restaurant**, address, phone, and email across pages.
- Replace images in `assets/` with your own (keep the same filenames or update the `src`).
- Edit the menu items and prices in `menu.html`.

## Hosting
- Works as static files—no backend required. Can be hosted on GitHub Pages, Netlify, or any web host.
